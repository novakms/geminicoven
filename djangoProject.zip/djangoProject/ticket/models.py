import uuid
from django.db import models
from users.models import User


class Ticket(models.Model):
    status_choise = (
        ('Active', 'Active'),
        ('Completed', 'Completed'),
        ('Pending', 'Pending')
    )
    ticket_number = models.UUIDField(default=uuid.uuid4)
    title = models.CharField('Задание', max_length=100)
    description = models.TextField('Текст поручения')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_by', null=True, blank=True)
    date_created = models.DateTimeField('Дата создания', auto_now_add=True)
    assigned_to = models.ForeignKey(User, on_delete=models.DO_NOTHING, null=True, blank=True)
    is_resolved = models.BooleanField(default=False)
    accepted_date = models.DateTimeField('Дата начала', null=True, blank=True)
    closed_date = models.DateTimeField('Дата завершения', null=True, blank=True)
    ticket_status = models.CharField('Статус', max_length=15, choices=status_choise)
    wes = models.IntegerField('Вес')
    pre = models.IntegerField('Приоритет')

    def __str__(self):
        return self.title
